<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <link rel="stylesheet" type="text/css" href="design/global.css" media="all" />
<link rel="shortcut icon" type="image/x-icon"   href="http://freed0m4all.org/img/logo.png" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en" />
  <title>Streisand!</title>
  <meta name="description" content="" />
</head>

<body>
<div id="wrapper">
<h1>Streisand project.</h1>
  <ul id="nav">
    <li><a href="index.php" class="current">Home</a></li>
    <li><a href="http://chat.freed0m4all.org">Chat (IRC)</a></li>
  </ul>

  <div id="content">
    <p id="languages"> 
<strong>Traduccion :</strong><a href="indexen.html"><acronym title="english">english</acronym></a>,<a href="index.php"><acronym title="spanish">español</acronym></a>, <a href="indexbr.html">português</a>|<a href="help.php">Help translate.</a></p>
    <div id="aside">
      <p><img src="design/streisandpuppets.jpg" alt="" width="252px" /></p>

      <p id="download">
        <a href="source.tar.gz">
          <span>Descarga este website.</span><br/>
        source.tar.gz</a>
      </p>

      <h2>Archivo y Ops</h2>
      <ul>
        <li><a href="http://s1.streisand.freed0m4all.org/tuto4pc.htm" class="external">Censura por Tuto4pc</a></li>
        <li><a href="http://piratenpad.de/wikileaks" class="external">Wikileaks Mirror Project</a></li>
        <li><a href="http://s1.streisand.freed0m4all.org/telecomix.org/" class="external">Telecomix.org</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/datalove.me/" class="external">Datalove.me</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/broadcast.telecomix.org/" class="external">Broadcast.telecomix.org 2012</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/bluecabinet.info/" class="external">Bluecabinet.info (just index)</a></li>
      </ul>
    </div>

<div id="main">
 
<h2>Help translate.</h2> 
 
<p>If you could help us translate these texts properly please send an email to Streisand (at) freed0m4all (dot) org.</p>
<p>Translation is required for the tutorial and index.</p>
<p>(Human translation, no automated translation)</p>
<p>Thank you! &lt;3</p>
</div> 
<p id="footer">Created  by <a href="http://telecomix.org/">Telecomix</a> and hosted by <a href="http://freed0m4all.org">Freed0m4All</a>.<br/>
  No copyright, no license.<br />
<img name="" src="design/logo.png" width="30" height="30" alt="" /> <img src="design/telecomix.gif" width="30px" alt="Telecomix" /></p>
</body> 
</html> 

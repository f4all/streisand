<!DOCTYPE html PUBLIC
  "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
  <link rel="stylesheet" type="text/css" href="./design/global.css" media="all" />
<link rel="shortcut icon" type="image/x-icon"   href="http://freed0m4all.org/img/logo.png" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="fr" />
  <title>Streisand me !</title>
  <meta name="description" content="" />
</head>

<body>
<div id="wrapper">
  <h1>Streisand project.</h1>
  <ul id="nav">
    <li><a href="#" class="current">Home</a></li>
    <li><a href="http://chat.freed0m4all.org">Chat (IRC)</a></li>
  </ul>

  <div id="content">
    <p id="languages"> 
     <strong>Translations :</strong><a href="indexen.html"><acronym title="english">english</acronym></a>,<a href="index.php"><acronym title="spanish">español</acronym></a>, <a href="indexbr.html">português</a><acronym title="spanish">|</acronym><a href="help.php"><acronym title="spanish">Help translate.</acronym></a></p>
   <div id="aside">
  <p><img src="./design/streisandpuppets.jpg" alt="" width="252px" /></p>

      <p id="download">
        <a href="source.tar.gz">
          <span>Baixe este website</span>.<span>.</span><br/>
        source.tar.gz</a>
      </p>
<h2>Arquivo e Ops</h2>
      <ul>
        <li><a href="http://s1.streisand.freed0m4all.org/tuto4pc.htm" class="external">Censura por Tuto4pc</a></li>
        <li><a href="http://piratenpad.de/wikileaks" class="external">Wikileaks Mirror Project</a></li>
        <li><a href="http://s1.streisand.freed0m4all.org/telecomix.org/" class="external">Telecomix.org</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/datalove.me/" class="external">Datalove.me</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/broadcast.telecomix.org/" class="external">Broadcast.telecomix.org 2012</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/bluecabinet.info/" class="external">Bluecabinet.info (just index)</a></li>
      </ul>
   </div>
<div id="main">
  <h2>Introdução</h2>
  <p>Para manter o fluxo de funcionamento, informações e de percurso em torno  da censura, aqui estão algumas orientações sobre como configurar um  espelho de alguns vídeos que o mundo precisa conhecer.  </p>
  <p><strong>Isto é como a censura na web funciona:</strong></p>
  <p>O governo encontra-se sobre um  site, em seguida, adiciona a um filterlist. Agora, este é, naturalmente,  muito fácil de contornar. Você só mover o site para um novo número IP  ou alterar a URL a ele. Para ser um passo à frente dos censores, nós  usamos o Efeito Streisand famoso para contornar o problema. O efeito  Streisand estipula que quanto mais alguém tenta censurar conteúdos na  internet, mais ele é copiado. Ele trabalha para os 2000 espelhos  Wikileaks, e que trabalha para praticamente qualquer projeto. Há talvez 2  bilhões de computadores no mundo para escolher, porque você pode ser um  espelho também.  </p>
  <h2>Vamos fazer isso!</h2>
  <ol>
    <li>
      <p>Primeiro você precisa de uma conexão com a internet. A um muito ruim vai  realmente fazer, e uma conexão de casa é suficiente, dado que há muitos  deles.</p>
    </li>
    <li>Em segundo lugar você precisa de um servidor web. No Linux você tem o  servidor Apache excelente, que no Debian / Ubuntu é instalado e iniciado  com o comando sudo apt-get install apache2. Na maioria das versões do  Mac OS já está instalado, e você ativá-lo nas preferências de rede /  compartilhamento. No Windows, eu não tenho certeza de como fazer isso  (por favor comente!). </li>
    <li>
      <p>Encaminhar as portas em seu roteador doméstico, se você tiver um. Você  quer que a porta 80 para ir ao local de número IP do seu servidor web.</p>
    </li>
    <li>est o servidor web para ver que ele funciona. Primeiro você simplesmente digitar http://localhost no seu navegador, e você deve ver uma página dizendo &quot;Apache foi criado  com sucesso&quot; ou similar. Em seguida, tente acessá-lo a partir da  Internet, para ver se suas obras de redirecionamento de porta. </li>
    <li>Copie os arquivos espelho e descompacte-os no diretório que o Apache  aponta. No Linux ele geralmente padrão aponta para / var / www onde você  pode colocar os arquivos. Em um Mac, ele está em algum lugar em sua  pasta pessoal (se bem me lembro). Por favor, coloque também o arquivo  zip original no diretório, para que outros possam copiar o seu espelho.  Efeito Streisand é recursiva, você sabe, como um fractal.</li>
    <li>
      <p>Uma vez que os arquivos, incluindo o index.*, é nesse diretório  específico, o espelho deve trabalhar para empurrar o tráfego nas  interwebs. Pergunte aos seus amigos para experimentá-lo. Se isso não  funcionar, consulte um manual do Apache.</p>
    </li>
    <li><strong>Parabéns.</strong> Você participou da maquinaria da política de internet e contribuiu para a impossibilidade de censura do governo.</li>
    <li>
      <p>Adicione a sua localização para nós ao anunciar que em nossos canais de  bate-papo. Além disso, sinta-se livre para discutir com internautas no <strong>#streisand</strong> no <strong>irc.freed0m4all.org</strong>.</p></li>
  </ol>
<p id="footer">Created  by <a href="http://telecomix.org/">Telecomix</a> and hosted by <a href="http://freed0m4all.org">Freed0m4All</a>.<br/>
  No copyright, no license.<br />
  <img name="" src="design/logo.png" width="30" height="30" alt="" /> <img src="design/telecomix.gif" width="30px" alt="Telecomix" /></p>
</div>
</div>
</body>
</html>

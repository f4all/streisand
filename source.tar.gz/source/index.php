<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <link rel="stylesheet" type="text/css" href="design/global.css" media="all" />
<link rel="shortcut icon" type="image/x-icon"   href="http://freed0m4all.org/img/logo.png" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en" />
  <title>Streisand!</title>
  <meta name="description" content="" />
</head>

<body>
<div id="wrapper">
<h1>Streisand project.</h1>
  <ul id="nav">
    <li><a href="index.php" class="current">Home</a></li>
    <li><a href="http://chat.freed0m4all.org">Chat (IRC)</a></li>
  </ul>

  <div id="content">
    <p id="languages"> 
<strong>Traduccion :</strong><a href="indexen.html"><acronym title="english">english</acronym></a>,<a href="index.php"><acronym title="spanish">español</acronym></a>, <a href="indexbr.html">português</a> |<a href="ayuda.php">Ayuda a traducir.</a></p>
    <div id="aside">
      <p><img src="design/streisandpuppets.jpg" alt="" width="252px" /></p>

      <p id="download">
        <a href="source.tar.gz">
          <span>Descarga este website.</span><br/>
        source.tar.gz</a>
      </p>

      <h2>Archivo y Ops</h2>
      <ul>
        <li><a href="http://s1.streisand.freed0m4all.org/tuto4pc.htm" class="external">Censura por Tuto4pc</a></li>
        <li><a href="http://piratenpad.de/wikileaks" class="external">Wikileaks Mirror Project</a></li>
        <li><a href="http://s1.streisand.freed0m4all.org/telecomix.org/" class="external">Telecomix.org</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/datalove.me/" class="external">Datalove.me</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/broadcast.telecomix.org/" class="external">Broadcast.telecomix.org 2012</a></li>
<li><a href="http://s1.streisand.freed0m4all.org/bluecabinet.info/" class="external">Bluecabinet.info (just index)</a></li>
      </ul>
    </div>

<div id="main">
 
<h2>Introducción / Qué es esto.</h2> 
 
<p>Streisand me! es un servicio de la orgullosa gente de Internet. Este es un lugar de encuentro y una página de recursos para todo aquel que quiera participar en la creación de un Internet resistente a la censura.</p> 
<p>Así es como funciona: Un conocido fenómeno de Internet es el <a href="https://secure.wikimedia.org/wikipedia/es/wiki/Efecto_Streisand">Efecto Streisand</a>. Cada vez que algo importante o popular es bloqueado, retirado o censurado, Internet encuentra una forma de mantenerlo online. Esto sucede por el hecho de que Internet son humanos que se niegan a mantener sus bocas cerradas sólo porque alguna autoridad les diga que lo hagan. Esto a menudo se traduce en una rápida propagación regional o incluso global y una amplia difusión de la información eliminada de forma digital en Internet. tl;dr: Internet nunca olvida.</p>
<p>En muchos lugares del mundo, la información que no es aceptada por política, religión o algún otro motivo aleatorio, es bloqueada por las autoridades, proveedores de acceso o empresarios. Para poner fin a ese comportamiento de los estados y las corporaciones te ofrecemos Streisand.me.</p> 
<p>Hay aproximadamente 2 mil millones de nodos en Internet. Cada uno de esos nodos puede ser un pequeño servidor espejo. Sí, incluso tu ordenador si está conectado a Internet. No hay forma práctica, incluso para el más severo de los regímenes, de impedir que dupliquemos el contenido bloqueado. Estamos en el lado ganador, sólo necesitamos empezar a copiar cosas - necesitamos intensificar el efecto Streisand. ¡Este sitio va sobre cómo conseguir eso!</p>

 
<h2>Cómo hacer tu propio servidor espejo (mirror).</h2> 
 
<p>Para duplicar un sitio necesitas un servidor web activo. Después nos debes notificar el servidor y nosotros nos encargaremos de enviarlo a las redes censuradas después de verificarlo. Mira nuestro <a href="tutoriales.php">Tutorial General</a> sobre cómo crear un servidor web.</p> 

<h2>Cómo contactarte con nosotros.</h2> 
 
<p>Únete al canal <span class="code">#streisand</span> en <span class="code"><a href="rc://irc.freed0m4all.org/streisand">irc.freed0m4all.org</a></span>. O para un acceso más fácil, ve al <a href="http://chat.freed0m4all.org">Chat F4All</a> y elige <span class="code">#streisand</span> como tu canales.</p>
 
<h2>Quién está detrás de streisand proyect.</h2> 
 
<p>Este sitio está dirigido por internautas que han estado duplicando sitios y atravesando a través de firewalls censores durante mucho tiempo. El proyecto actualmente está alojado en <a href="http://freed0m4all.org">Freed0m4All</a> y fue creado por <a href="http://telecomix.org/">Telecomix</a>, que es un grupo y un punto de encuentro para activistas de Internet de todo el mundo.</p> 

</div> 
<p id="footer">Created  by <a href="http://telecomix.org/">Telecomix</a> and hosted by <a href="http://freed0m4all.org">Freed0m4All</a>.<br/>
  No copyright, no license.<br />
<img name="" src="design/logo.png" width="30" height="30" alt="" /> <img src="design/telecomix.gif" width="30px" alt="Telecomix" /></p>
</body> 
</html> 
